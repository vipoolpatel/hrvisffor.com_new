<?php

return [
  
    'Feedback List' => 'Feedback List',
    'Title'         => 'Title',
    'Review'        => 'Review',
    'Photo'         => 'Photo',
    'Video'         => 'Video',
    'Action'        => 'Action',
    'Photo (Minimum 1 Photo)'  => 'Photo (Minimum 1 Photo)',

    'Minimum 50 words'  => 'Minimum 50 words',
    'Add More Photo'    => 'Add More Photo',
    'Update'            => 'Update',
    'Delete'            => 'Delete',
    'Are you sure you want to delete?'  => 'Are you sure you want to delete?',
        

    

  
    
];
