<?php

return [
  
    "Work in China"                           => "Work in China",
    "Artificial Intelligence Matching System" => "Artificial Intelligence Matching System",
    "Get Started"                             => "Get Started",
    "Base FAQ Questions"                      => "Base FAQ Questions",
    "Tutorials"                               => "Tutorials",
    "Books & Articles"                        => "Books & Articles",
    "User Guide"                              => "User Guide",
    "Complete Knowledgebase"                  => "Complete Knowledgebase",
    "FAQ"                                     => "FAQ",
    "About China"                             => "About China",
    "How to become an English teacher in China?" => "How to become an English teacher in China?",
    "Hide"                                    => "Hide",
    "Read More"                               => "Read More",
    "Cost of living-Teaching English in China" => "Cost of living-Teaching English in China",
    "How much you Earn Teaching English in China" => "How much you Earn Teaching English in China",
    "Get in Touch"                              => "Get in Touch",
    "Windows 10 automatically installs updates to make for sure" => "Windows 10 automatically installs updates to make for sure",
    "Submit a Request"                         => "Submit a Request",
    "Keenthemes"                               => "Keenthemes",
    "About"                                    => "About",

    "Team"                                     => "Team",
    "Contact"                                  => "Contact",
    "Ask a question"                           => "Ask a question",
    "The Truth about Working in China as a Foreigner" => "The Truth about Working in China as a Foreigner",
    
];
