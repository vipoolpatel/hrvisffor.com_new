<?php

return [

    'failed' => 'These credentials do not match our records.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',


    "VISFFOR"                                   => "VISFFOR",
    "Forgot Password"                           => "Forgot Password",
    "Or"                                        => "Or",
    "Sign In"                                   => "Sign In",
    "Username"                                  => "Username",
    "Forgot"                                    => "Forgot",
    "WE FOR YOU"                                => "WE FOR YOU",
    "VISFFOR, a UK-based company with other main offices in the United States, Canada," 
                                                => "VISFFOR, a UK-based company with other main offices in the United States, Canada,",
    "Austria and China, aims to promoting cultural"  
                                                => "Austria and China, aims to promoting cultural",
    
    "exchanges among countries."                => "exchanges among countries.",
    "Forgot Username"                           => "Forgot Username",
    "Email"                                     => "Email",
    "Austria and China, aims to promoting cultural <br /> exchanges among countries." 
                                                => "Austria and China, aims to promoting cultural <br /> exchanges among countries.",
    "Create An Account"                         => "Create An Account",
    "Forgot Username ?"                         => "Forgot Username ?",
    "Password"                                  => "Password",

    "Sign Up"                                   => "Sign Up",
    "Enter your details to create your account" => "Enter your details to create your account",
    "Register as"                               => "Register as",
    "Teacher"                                   => "Teacher",
    "School"                                    => "School",
    "Password Confirmation"                     => "Password Confirmation",
    "Verification Code"                         => "Verification Code",
    "Submit"                                    => "Submit",
    "Reset Password"                            => "Reset Password",
    "Reset"                                     => "Reset",
   


];
