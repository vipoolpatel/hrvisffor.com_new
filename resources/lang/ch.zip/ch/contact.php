<?php

return [
  
  "Looking for Help?"               => "Looking for Help?",
  "Submit your help request to one of our Metronic Experts!" 
                                    => "Submit your help request to one of our Metronic Experts!",
  "Send us your enquiries"          => "Send us your enquiries",
  "Name"                            => "Name",
  "Enter your name"                 => "Enter your name",
  "Email address"                   => "Email address",
  "Enter email"                     => "Enter email",
  "Phone"                           => "Phone",
  "Enter your phone"                => "Enter your phone",
  "Subject"                         => "Subject",
  "Enter your subject"              => "Enter your subject",
  "Your Message"                    => "Your Message",
  "Verification Code"               => "Verification Code",
  "Submit"                          => "Submit",
  "Cancel"                          => "Cancel",
  "Or Reach Us by Live Chat"        => "Or Reach Us by Live Chat",
  "Windows 10 automatically installs updates" 
                                    => "Windows 10 automatically installs updates",
  "to make for sure"                => "to make for sure",
  "Contact Us"                      => "Contact Us",

 
  

];
