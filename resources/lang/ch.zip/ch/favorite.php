<?php

return [

    'Favorite School Job'   => 'Favorite School Job',
    'Location'              => 'Location',
    'Salary'                => 'Salary',
    'Monthly Salary'                => 'Monthly Salary',
    'Are you sure you want to delete?' => 'Are you sure you want to delete?',
    'Favorite Teacher'                => 'Favorite Teacher',
    
    
    

    
 

];
