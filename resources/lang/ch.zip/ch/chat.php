<?php

return [
  
    'Send'                    => 'Send',
    'Type a message'          => 'Type a message',

    'Try selecting a conversation or searching for someone specific.' => 'Try selecting a conversation or searching for someone specific.',

    'Select a Conversation'   => 'Select a Conversation',
    'Active'                  => 'Active',
    'Load More'               => 'Load More',
    'Search Member'           => 'Search Member',

    'Add New Member'   	=> 'Add New Member',
    'Select Member'   	=> 'Select Member',
    'Add'   			=> 'Add',
    'You'   			=> 'You',

    'Leave Member'   		=> 'Leave Member',
    'Leave'   				=> 'Leave',
    'Search Group'   		=> 'Search Group',
    'Create New Group'  	=> 'Create New Group',
    'Add New Member'   		=> 'Add New Member',
    'Group Name'   			=> 'Group Name',
    'Select Member'   		=> 'Select Member',
    'Create'   				=> 'Create',
    'Select'   		    	=> 'Select',
    'Group successfully created'   => 'Group successfully created',
    'Member successfully removed'  => 'Member successfully removed',
    'Member successfully Add'      => 'Member successfully Add',
    'Search ID/Name '              => 'Search ID/Name',

  
    
];
