<?php

return [
  
    "Report List"       => "Report List",
    "Add New Report"    => "Add New Report",
    "Name"              => "Name",
    "Email"             => "Email",
    "Phone"             => "Phone",
    "Title"             => "Title",
    "Description"       => "Description",
    "Reject Rason"      => "Reject Rason",
    "Status"            => "Status",
    "Report"            => "Report",    
    "Close"             => "Close",
    "Save"              => "Save",  

    "Action"            => "Action",  
    "Reason"            => "Reason",  
    "Reject"            => "Reject",  
];
